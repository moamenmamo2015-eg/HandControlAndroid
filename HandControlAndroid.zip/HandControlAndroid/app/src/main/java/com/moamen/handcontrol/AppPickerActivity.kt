package com.moamen.handcontrol

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

/** List of installed apps with a checkbox each. Checked apps = where gestures work. */
class AppPickerActivity : AppCompatActivity() {

    private data class AppItem(val pkg: String, val name: String, val icon: Drawable?)

    private lateinit var prefs: Prefs
    private val selected = mutableSetOf<String>()
    private var all = listOf<AppItem>()
    private var shown = listOf<AppItem>()
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        selected += prefs.selectedApps
        val dp = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val search = EditText(this).apply {
            hint = "دوّر على تطبيق…"
            setSingleLine()
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins((16 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), 0)
        })
        val loading = ProgressBar(this)
        root.addView(loading, LinearLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = (24 * dp).toInt()
        })
        val list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@AppPickerActivity) }
        adapter = Adapter()
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
        })

        thread {
            val pm = packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val apps = pm.queryIntentActivities(launcher, 0)
                .map { it.activityInfo.packageName to it }
                .distinctBy { it.first }
                .filter { it.first != packageName }
                .map { (pkg, ri) -> AppItem(pkg, ri.loadLabel(pm).toString(), runCatching { ri.loadIcon(pm) }.getOrNull()) }
                // chosen apps first, then alphabetical
                .sortedWith(compareBy<AppItem>({ it.pkg !in selected }, { it.name.lowercase() }))
            runOnUiThread {
                all = apps
                loading.visibility = View.GONE
                filter(search.text.toString())
            }
        }
    }

    private fun filter(q: String) {
        shown = if (q.isBlank()) all else all.filter {
            it.name.contains(q, ignoreCase = true) || it.pkg.contains(q, ignoreCase = true)
        }
        adapter.notifyDataSetChanged()
    }

    override fun onPause() {
        super.onPause()
        prefs.selectedApps = selected
    }

    private inner class Holder(row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val icon = row.getChildAt(0) as ImageView
        val name = row.getChildAt(1) as TextView
        val check = row.getChildAt(2) as CheckBox
    }

    private inner class Adapter : RecyclerView.Adapter<Holder>() {
        override fun getItemCount() = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val dp = resources.displayMetrics.density
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((16 * dp).toInt(), (10 * dp).toInt(), (16 * dp).toInt(), (10 * dp).toInt())
                layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            row.addView(ImageView(parent.context), LinearLayout.LayoutParams((40 * dp).toInt(), (40 * dp).toInt()))
            row.addView(TextView(parent.context).apply {
                textSize = 16f
                setPadding((14 * dp).toInt(), 0, (14 * dp).toInt(), 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(CheckBox(parent.context).apply { isClickable = false })
            return Holder(row)
        }

        override fun onBindViewHolder(h: Holder, position: Int) {
            val item = shown[position]
            h.icon.setImageDrawable(item.icon)
            h.name.text = item.name
            h.check.isChecked = item.pkg in selected
            h.itemView.setOnClickListener {
                if (!selected.remove(item.pkg)) selected += item.pkg
                h.check.isChecked = item.pkg in selected
                prefs.selectedApps = selected
            }
        }
    }
}
