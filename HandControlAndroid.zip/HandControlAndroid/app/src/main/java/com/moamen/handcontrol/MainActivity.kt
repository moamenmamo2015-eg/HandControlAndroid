package com.moamen.handcontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private val dp by lazy { resources.displayMetrics.density }

    private lateinit var cameraStatus: TextView
    private lateinit var notifStatus: TextView
    private lateinit var a11yStatus: TextView
    private lateinit var appsStatus: TextView
    private lateinit var batteryStatus: TextView
    private lateinit var startButton: MaterialButton
    private lateinit var liveText: TextView
    private lateinit var errorText: TextView

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    private val ticker = object : Runnable {
        override fun run() { refresh(); ui.postDelayed(this, 300) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        title = "Hand Control"

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(px(16), px(12), px(16), px(32))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(text("تحكّم في الموبايل بإيدك قدام الكاميرا الأمامية، جوه التطبيقات اللي تختارها بس.", 15f))

        // ---------- setup steps ----------
        col.addView(header("الإعداد (مرة واحدة بس)"))

        cameraStatus = text("", 15f)
        col.addView(card(
            cameraStatus,
            button("اسمح بالكاميرا") { askCamera.launch(Manifest.permission.CAMERA) }
        ))

        notifStatus = text("", 15f)
        if (Build.VERSION.SDK_INT >= 33) {
            col.addView(card(
                notifStatus,
                button("اسمح بالإشعارات") { askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }
            ))
        }

        a11yStatus = text("", 15f)
        col.addView(card(
            a11yStatus,
            text(
                "هتفتح الإعدادات ← دوّر على Hand Control (غالبًا تحت \"التطبيقات المثبتة\" أو \"الخدمات المحمّلة\") ← فعّله ← موافق.\n\n" +
                    "⚠️ لو لقيت الاختيار رمادي أو ظهرلك \"إعداد مقيد\": ارجع هنا واضغط \"معلومات التطبيق\" ← النقط التلاتة ⋮ فوق ← \"السماح بالإعدادات المقيدة\"، وبعدين جرّب تاني.",
                13f
            ).apply { alpha = 0.8f },
            button("افتح إعدادات إمكانية الوصول") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            button("معلومات التطبيق", outlined = true) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        ))

        appsStatus = text("", 15f)
        col.addView(card(
            appsStatus,
            button("اختار التطبيقات") { startActivity(Intent(this, AppPickerActivity::class.java)) }
        ))

        batteryStatus = text("", 15f)
        col.addView(card(
            batteryStatus,
            text("اختياري، بس مهم على موبايلات زي أوبو وريلمي وشاومي علشان النظام ما يقفلش التطبيق لوحده.", 13f)
                .apply { alpha = 0.8f },
            button("اسمح بالعمل في الخلفية", outlined = true) { askBattery() }
        ))

        // ---------- start / stop ----------
        startButton = button("") { toggle() }.apply {
            textSize = 18f
            minHeight = px(60)
        }
        col.addView(startButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(16) })

        errorText = text("", 13f).apply { setTextColor(Color.rgb(239, 83, 80)); visibility = View.GONE }
        col.addView(errorText)

        // ---------- live test ----------
        col.addView(header("جرّب هنا"))
        col.addView(
            text("وإنت في الشاشة دي التطبيق بيتعرف على إيدك من غير ما ينفذ أي حاجة، علشان تتدرّب.", 13f)
                .apply { alpha = 0.8f }
        )
        col.addView(SkeletonView(this), LinearLayout.LayoutParams(-1, px(300)).apply { topMargin = px(8) })
        liveText = text("", 22f).apply { gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD) }
        col.addView(liveText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(8) })

        // ---------- gesture → action ----------
        col.addView(header("كل إيماءة تعمل إيه؟"))
        val actions = Action.values()
        for (g in Gesture.usable) {
            col.addView(text("${g.emoji}  ${g.label}", 15f).apply { setTypeface(typeface, Typeface.BOLD) },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(12) })
            val spinner = Spinner(this)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, actions.map { it.label })
            spinner.setSelection(actions.indexOf(prefs.actionFor(g)))
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = prefs.setAction(g, actions[pos])
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(spinner)
        }
        col.addView(button("رجّع الإعدادات الأصلية", outlined = true) {
            Gesture.usable.forEach { prefs.setAction(it, it.defaultAction) }
            recreate()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(8) })

        // ---------- options ----------
        col.addView(header("خيارات"))
        col.addView(SwitchCompat(this).apply {
            text = "أظهر فقاعة صغيرة بالإيماءة اللي شايفها جوه التطبيقات"
            isChecked = prefs.showBadge
            setOnCheckedChangeListener { _, on -> prefs.showBadge = on }
        })
        col.addView(text("سرعة الاستجابة", 15f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(12) })
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        listOf(1 to "متأنية (أخطاء أقل)", 2 to "عادية", 3 to "سريعة").forEach { (v, label) ->
            group.addView(RadioButton(this).apply {
                id = View.generateViewId(); text = label; tag = v; isChecked = prefs.speed == v
            })
        }
        group.setOnCheckedChangeListener { g, checkedId -> prefs.speed = g.findViewById<View>(checkedId).tag as Int }
        col.addView(group)

        col.addView(text(
            "نصايح: خلّي إيدك على بعد نص متر تقريبًا من الكاميرا، والإضاءة كويسة، وامسك الإيماءة ثانية. " +
                "التشغيل/الإيقاف والتالي/السابق بيشتغلوا مع أغلب تطبيقات الفيديو والموسيقى. " +
                "لو تطبيق مش بيستجيب، جرّب السحب أو الدبل تاب بدلهم.",
            13f
        ).apply { alpha = 0.7f }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(20) })
    }

    override fun onResume() {
        super.onResume()
        Hub.testMode = true
        ui.post(ticker)
    }

    override fun onPause() {
        Hub.testMode = false
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------- logic ----------

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun a11yOn(): Boolean {
        if (Hub.accessibility != null) return true
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return list.contains(packageName) && list.contains("ControlAccessibilityService")
    }

    private fun batteryOk(): Boolean {
        if (Build.VERSION.SDK_INT < 23) return true
        return getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
    }

    private fun askBattery() {
        if (Build.VERSION.SDK_INT < 23) return
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun toggle() {
        if (Hub.cameraRunning) {
            HandCameraService.stop(this)
            return
        }
        if (!hasCamera()) {
            askCamera.launch(Manifest.permission.CAMERA)
            return
        }
        if (!a11yOn()) {
            Toast.makeText(this, "هتقدر تجرّب هنا، بس علشان يشتغل جوه التطبيقات لازم تفعّل خطوة إمكانية الوصول", Toast.LENGTH_LONG).show()
        } else if (prefs.selectedApps.isEmpty()) {
            Toast.makeText(this, "لسه ما اخترتش أي تطبيق", Toast.LENGTH_LONG).show()
        }
        Hub.lastError = null
        HandCameraService.start(this)
    }

    private fun refresh() {
        cameraStatus.text = mark(hasCamera()) + "١. إذن الكاميرا"
        notifStatus.text = mark(hasNotif()) + "٢. إذن الإشعارات"
        a11yStatus.text = mark(a11yOn()) + "٣. تفعيل Hand Control في إمكانية الوصول"
        val n = prefs.selectedApps.size
        appsStatus.text = mark(n > 0) + "٤. التطبيقات المختارة: " + (if (n == 0) "ولا واحد" else "$n")
        batteryStatus.text = mark(batteryOk()) + "٥. العمل في الخلفية"

        val running = Hub.cameraRunning
        startButton.text = if (running) "⏹  إيقاف" else "▶  تشغيل"
        startButton.setBackgroundColor(if (running) Color.rgb(198, 40, 40) else Color.rgb(124, 77, 255))

        val err = Hub.lastError
        errorText.visibility = if (err == null) View.GONE else View.VISIBLE
        errorText.text = err ?: ""

        val g = Hub.gesture
        val recentlyFired = SystemClock.uptimeMillis() - Hub.lastFiredAt < 700
        liveText.text = when {
            !running -> ""
            Hub.landmarks == null -> "مفيش إيد ظاهرة"
            g == Gesture.NONE -> "✋ شايف إيدك"
            else -> "${g.emoji}  ${g.label}\n← ${prefs.actionFor(g).label}"
        }
        liveText.setTextColor(if (recentlyFired) Color.rgb(255, 112, 67) else currentTextColor())
    }

    private fun currentTextColor(): Int = cameraStatus.currentTextColor

    private fun mark(ok: Boolean) = if (ok) "✅  " else "⬜  "

    // ---------- tiny view helpers ----------

    private fun px(v: Int) = (v * dp).toInt()

    private fun text(s: String, size: Float) = TextView(this).apply {
        text = s; textSize = size; setPadding(0, px(4), 0, px(4))
    }

    private fun header(s: String) = text(s, 19f).apply {
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, px(24), 0, px(6))
    }

    private fun button(label: String, outlined: Boolean = false, onClick: () -> Unit): MaterialButton {
        val b = if (outlined)
            MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        else MaterialButton(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(vararg views: View): MaterialCardView {
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(14), px(10), px(14), px(10))
        }
        views.forEach { inner.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        return MaterialCardView(this).apply {
            radius = px(14).toFloat()
            cardElevation = px(2).toFloat()
            addView(inner)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(10) }
        }
    }
}
