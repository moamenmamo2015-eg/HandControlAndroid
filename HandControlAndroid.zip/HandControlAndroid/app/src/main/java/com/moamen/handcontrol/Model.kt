package com.moamen.handcontrol

import android.content.Context
import android.content.SharedPreferences

/** The hand shapes the app recognises. */
enum class Gesture(val emoji: String, val label: String, val repeats: Boolean, val defaultAction: Action) {
    NONE("", "", false, Action.NOTHING),
    THUMBS_UP("👍", "إبهام لفوق", true, Action.VOLUME_UP),
    THUMBS_DOWN("👎", "إبهام لتحت", true, Action.VOLUME_DOWN),
    POINT_RIGHT("👉", "شاوِر يمين بالسبابة", false, Action.MEDIA_NEXT),
    POINT_LEFT("👈", "شاوِر شمال بالسبابة", false, Action.MEDIA_PREVIOUS),
    PINCH("🤏", "اقفل الإبهام على السبابة", false, Action.PLAY_PAUSE);

    companion object {
        val usable = values().filter { it != NONE }
    }
}

/** What a gesture can do. Performed by [ControlAccessibilityService]. */
enum class Action(val label: String) {
    VOLUME_UP("رفع الصوت"),
    VOLUME_DOWN("خفض الصوت"),
    PLAY_PAUSE("تشغيل / إيقاف مؤقت"),
    MEDIA_NEXT("المقطع التالي (ميديا)"),
    MEDIA_PREVIOUS("المقطع السابق (ميديا)"),
    SWIPE_UP("سحب لفوق (الفيديو التالي في ريلز/تيك توك)"),
    SWIPE_DOWN("سحب لتحت (الفيديو السابق)"),
    SWIPE_LEFT("سحب لليسار (الصفحة التالية)"),
    SWIPE_RIGHT("سحب لليمين (الصفحة السابقة)"),
    TAP_CENTER("لمسة في نص الشاشة"),
    DOUBLE_TAP_RIGHT("دبل تاب يمين (تقديم 10 ثواني)"),
    DOUBLE_TAP_LEFT("دبل تاب شمال (ترجيع 10 ثواني)"),
    BACK("رجوع"),
    HOME("الشاشة الرئيسية"),
    NOTHING("ولا حاجة");
}

/** Saved settings. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("hand_control", Context.MODE_PRIVATE)

    var selectedApps: Set<String>
        get() = sp.getStringSet("apps", emptySet())?.toSet() ?: emptySet()
        set(value) = sp.edit().putStringSet("apps", HashSet(value)).apply()

    var showBadge: Boolean
        get() = sp.getBoolean("badge", true)
        set(value) = sp.edit().putBoolean("badge", value).apply()

    /** 1 = strict (fewer mistakes), 2 = normal, 3 = fast. */
    var speed: Int
        get() = sp.getInt("speed", 2)
        set(value) = sp.edit().putInt("speed", value).apply()

    fun actionFor(g: Gesture): Action {
        val name = sp.getString("action_${g.name}", null) ?: return g.defaultAction
        return runCatching { Action.valueOf(name) }.getOrDefault(g.defaultAction)
    }

    fun setAction(g: Gesture, a: Action) = sp.edit().putString("action_${g.name}", a.name).apply()
}

/** Live state shared between the camera service, the accessibility service and the screen. */
object Hub {
    /** Package of the app currently on screen, reported by the accessibility service. */
    @Volatile var foregroundPackage: String? = null
    @Volatile var accessibility: ControlAccessibilityService? = null
    @Volatile var cameraRunning = false
    /** True while the Hand Control screen itself is open: track the hand, but don't act. */
    @Volatile var testMode = false

    /** Latest hand points as x0,y0,x1,y1... in 0..1, already mirrored like a selfie. */
    @Volatile var landmarks: FloatArray? = null
    @Volatile var frameAspect = 0.75f
    @Volatile var gesture: Gesture = Gesture.NONE
    @Volatile var lastFired: Gesture = Gesture.NONE
    @Volatile var lastFiredAt = 0L
    @Volatile var lastError: String? = null
}
