package com.moamen.handcontrol

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Runs the front camera + hand tracking in the background (with a notification),
 * but only spends effort on frames while one of your chosen apps is on screen.
 */
class HandCameraService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.moamen.handcontrol.STOP"
        private const val CHANNEL = "hand_control"
        private const val NOTIF_ID = 7

        fun start(context: Context) =
            ContextCompat.startForegroundService(context, Intent(context, HandCameraService::class.java))

        fun stop(context: Context) =
            context.startService(Intent(context, HandCameraService::class.java).setAction(ACTION_STOP))
    }

    private enum class Mode { OFF, TEST, LIVE }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private var analysisExecutor: ExecutorService? = null
    private var landmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null

    @Volatile private var mode = Mode.OFF
    @Volatile private var resetEngine = false
    private var lastFrameAt = 0L
    private var lastHandAt = 0L
    @Volatile private var lastBadge: String? = null
    @Volatile private var lastMode = Mode.OFF

    private val engine = GestureEngine { g -> fire(g) }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // Must happen within a few seconds of starting.
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        )
        if (landmarker == null) startTracking()
        return START_STICKY
    }

    private fun startTracking() {
        try {
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(
                    BaseOptions.builder()
                        .setModelAssetPath("hand_landmarker.task")
                        .setDelegate(Delegate.CPU)
                        .build()
                )
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result: HandLandmarkerResult, input: MPImage -> onResult(result, input) }
                .setErrorListener { e: RuntimeException -> Hub.lastError = e.message }
                .build()
            landmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            Hub.lastError = "فشل تحميل نموذج اليد: ${e.message}"
            stopSelf()
            return
        }

        analysisExecutor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val analysis = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(640, 480),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                                )
                            ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(analysisExecutor!!) { analyze(it) }

                val selector = if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA))
                    CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, analysis)
                Hub.cameraRunning = true
                Hub.lastError = null
            } catch (e: Exception) {
                Hub.lastError = "مش قادر يفتح الكاميرا: ${e.message}"
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun currentMode(): Mode {
        if (Hub.testMode) return Mode.TEST
        val fg = Hub.foregroundPackage ?: return Mode.OFF
        if (Hub.accessibility == null) return Mode.OFF
        return if (fg in prefs.selectedApps) Mode.LIVE else Mode.OFF
    }

    /** Runs on the camera thread for every frame. */
    private fun analyze(image: ImageProxy) {
        val m = currentMode()
        if (m != lastMode) {
            lastMode = m
            resetEngine = true
            lastBadge = null
            // Hide the bubble only if we're still out of the app a moment later,
            // so a quick popup doesn't make it blink.
            if (m != Mode.LIVE) main.postDelayed({
                if (lastMode != Mode.LIVE) Hub.accessibility?.showBadge(null)
            }, 1200)
        }
        mode = m
        val now = SystemClock.uptimeMillis()
        // Off: ignore frames (almost no battery). On: ~15 frames a second is plenty.
        if (m == Mode.OFF || now - lastFrameAt < 66) {
            if (m == Mode.OFF) { Hub.landmarks = null; Hub.gesture = Gesture.NONE }
            image.close()
            return
        }
        lastFrameAt = now

        val bitmap: Bitmap
        try {
            val raw = image.toBitmap()
            val matrix = Matrix().apply {
                postRotate(image.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // mirror, so "right" means your right, like a selfie
            }
            bitmap = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        } catch (e: Exception) {
            image.close()
            return
        }
        image.close()
        try {
            landmarker?.detectAsync(BitmapImageBuilder(bitmap).build(), now)
        } catch (e: Exception) {
            Hub.lastError = e.message
        }
    }

    /** Called by MediaPipe with the hand points for a frame. */
    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        if (resetEngine) { engine.reset(); resetEngine = false }
        if (mode == Mode.OFF) return

        val w = input.width.toFloat()
        val h = input.height.toFloat()
        Hub.frameAspect = w / h
        val hand = result.landmarks().firstOrNull()

        val gesture: Gesture
        if (hand == null || hand.size < 21) {
            Hub.landmarks = null
            gesture = Gesture.NONE
        } else {
            val norm = FloatArray(42)
            val px = FloatArray(42)
            for (i in 0 until 21) {
                norm[i * 2] = hand[i].x()
                norm[i * 2 + 1] = hand[i].y()
                px[i * 2] = hand[i].x() * w
                px[i * 2 + 1] = hand[i].y() * h
            }
            Hub.landmarks = norm
            gesture = GestureClassifier.classify(px)
        }

        when (prefs.speed) {
            1 -> { engine.framesNeeded = 5; engine.repeatMs = 450 }
            3 -> { engine.framesNeeded = 2; engine.repeatMs = 250 }
            else -> { engine.framesNeeded = 3; engine.repeatMs = 350 }
        }
        val stable = engine.update(gesture, SystemClock.uptimeMillis())
        Hub.gesture = stable

        if (mode == Mode.LIVE && prefs.showBadge) {
            val now = SystemClock.uptimeMillis()
            if (hand != null) lastHandAt = now
            // Only switch to "no hand" after the hand has really been gone for a bit.
            val badge = when {
                hand != null -> stable.emoji.ifEmpty { "✋" }
                now - lastHandAt < 700 -> null // keep whatever is showing
                else -> "·"
            }
            if (badge != null && badge != lastBadge) {
                lastBadge = badge
                main.post { Hub.accessibility?.showBadge(badge) }
            }
        } else if (!prefs.showBadge && lastBadge != null) {
            lastBadge = null
            main.post { Hub.accessibility?.showBadge(null) }
        }
    }

    private fun fire(g: Gesture) {
        Hub.lastFired = g
        Hub.lastFiredAt = SystemClock.uptimeMillis()
        if (mode != Mode.LIVE) return // in test mode we only show it on screen
        val action = prefs.actionFor(g)
        main.post { Hub.accessibility?.perform(action) }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Hand Control", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, HandCameraService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Hand Control شغال")
            .setContentText("بيتابع إيدك جوه التطبيقات اللي اخترتها بس")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "إيقاف", stop)
            .build()
    }

    override fun onDestroy() {
        Hub.cameraRunning = false
        Hub.landmarks = null
        Hub.gesture = Gesture.NONE
        main.post { Hub.accessibility?.showBadge(null) }
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        analysisExecutor?.shutdown()
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        super.onDestroy()
    }
}
