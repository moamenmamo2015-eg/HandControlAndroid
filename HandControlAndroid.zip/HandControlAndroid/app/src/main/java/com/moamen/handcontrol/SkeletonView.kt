package com.moamen.handcontrol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Draws the hand skeleton the camera sees, like the laptop version's window. */
class SkeletonView(context: Context) : View(context) {

    private val bones = intArrayOf(
        0, 1, 1, 2, 2, 3, 3, 4,          // thumb
        0, 5, 5, 6, 6, 7, 7, 8,          // index
        5, 9, 9, 10, 10, 11, 11, 12,     // middle
        9, 13, 13, 14, 14, 15, 15, 16,   // ring
        13, 17, 17, 18, 18, 19, 19, 20, 0, 17 // pinky + palm
    )
    private val bg = Paint().apply { color = Color.rgb(20, 18, 32) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(124, 77, 255); strokeWidth = 8f; strokeCap = Paint.Cap.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 112, 67) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 255, 255, 255); textAlign = Paint.Align.CENTER
    }
    private val frame = RectF()

    private val ticker = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 33) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(ticker) }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        // Fit the camera frame (keep its shape) inside the view.
        val aspect = Hub.frameAspect.coerceIn(0.3f, 3f)
        var fw = width.toFloat()
        var fh = fw / aspect
        if (fh > height) { fh = height.toFloat(); fw = fh * aspect }
        frame.set((width - fw) / 2, (height - fh) / 2, (width + fw) / 2, (height + fh) / 2)
        canvas.drawRoundRect(frame, 24f, 24f, bg)

        val pts = Hub.landmarks
        if (pts == null) {
            text.textSize = 15f * resources.displayMetrics.density
            val msg = if (Hub.cameraRunning) "ورّي إيدك للكاميرا الأمامية" else "اضغط تشغيل الأول"
            canvas.drawText(msg, frame.centerX(), frame.centerY(), text)
            return
        }
        fun px(i: Int) = frame.left + pts[i * 2] * fw
        fun py(i: Int) = frame.top + pts[i * 2 + 1] * fh
        var i = 0
        while (i < bones.size) {
            canvas.drawLine(px(bones[i]), py(bones[i]), px(bones[i + 1]), py(bones[i + 1]), line)
            i += 2
        }
        for (p in 0 until 21) canvas.drawCircle(px(p), py(p), 9f, dot)
    }
}
