package com.moamen.handcontrol

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Turns the 21 hand points from MediaPipe into one [Gesture].
 *
 * Point numbers (MediaPipe):
 *   0 wrist
 *   1-4  thumb   (4 = tip)
 *   5-8  index   (5 = knuckle, 6 = middle joint, 8 = tip)
 *   9-12 middle, 13-16 ring, 17-20 pinky
 *
 * [pts] holds x0,y0,x1,y1,... in pixels; y grows downward.
 */
object GestureClassifier {

    fun classify(pts: FloatArray): Gesture {
        fun x(i: Int) = pts[i * 2]
        fun y(i: Int) = pts[i * 2 + 1]
        fun d(a: Int, b: Int) = hypot(x(a) - x(b), y(a) - y(b))

        val hand = d(0, 9) // palm size, makes everything distance-independent
        if (hand < 1f) return Gesture.NONE

        // A finger is "curled" when its tip is closer to the wrist than its middle joint.
        fun curled(tip: Int, pip: Int) = d(tip, 0) < d(pip, 0)
        fun extended(tip: Int, pip: Int) = d(tip, 0) > d(pip, 0) * 1.12f

        val indexCurled = curled(8, 6)
        val indexOut = extended(8, 6)
        val othersCurled = curled(12, 10) && curled(16, 14) && curled(20, 18)

        // 🤏 Pinch: thumb tip touching index tip, with the index not tucked into a fist.
        if (d(4, 8) < 0.25f * hand && d(8, 5) > 0.45f * hand) return Gesture.PINCH

        // ✌️ Victory: index + middle out, ring + pinky folded (thumb can be anywhere).
        if (indexOut && extended(12, 10) && curled(16, 14) && curled(20, 18)) return Gesture.PEACE

        // 👍 / 👎: fist with the thumb sticking out straight up or down.
        if (othersCurled && indexCurled) {
            val vx = x(4) - x(2)
            val vy = y(4) - y(2)
            if (hypot(vx, vy) > 0.45f * hand && abs(vy) > 1.4f * abs(vx)) {
                return if (vy < 0) Gesture.THUMBS_UP else Gesture.THUMBS_DOWN
            }
        }

        // 👉 / 👈: only the index finger out, pointing sideways.
        if (othersCurled && indexOut) {
            val vx = x(8) - x(5)
            val vy = y(8) - y(5)
            if (hypot(vx, vy) > 0.5f * hand && abs(vx) > 1.3f * abs(vy)) {
                return if (vx > 0) Gesture.POINT_RIGHT else Gesture.POINT_LEFT
            }
        }
        return Gesture.NONE
    }
}

/**
 * Smooths the per-frame guesses so a single shaky frame never fires an action,
 * and decides when to fire: once per gesture, or repeatedly while held for 👍/👎.
 */
class GestureEngine(private val onFire: (Gesture) -> Unit) {
    private var candidate = Gesture.NONE
    private var candidateFrames = 0
    private var confirmed = Gesture.NONE
    private var lastFire = 0L

    var framesNeeded = 3
    var repeatMs = 350L

    fun update(g: Gesture, now: Long): Gesture {
        if (g == candidate) candidateFrames++ else { candidate = g; candidateFrames = 1 }

        if (candidateFrames >= framesNeeded && candidate != confirmed) {
            confirmed = candidate
            if (confirmed != Gesture.NONE) { onFire(confirmed); lastFire = now }
        } else if (confirmed.repeats && confirmed == candidate && now - lastFire >= repeatMs) {
            onFire(confirmed); lastFire = now
        }
        return confirmed
    }

    fun reset() { candidate = Gesture.NONE; candidateFrames = 0; confirmed = Gesture.NONE }
}
