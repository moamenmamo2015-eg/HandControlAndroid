package com.moamen.handcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.TextView

/**
 * Two jobs:
 *  1. Tell the camera service which app is on screen (so it only works in your chosen apps).
 *  2. Carry out the actions: volume, media keys, swipes, taps, back/home.
 * It never reads what is on the screen.
 */
class ControlAccessibilityService : AccessibilityService() {

    private var badge: TextView? = null
    private var ignored: Set<String> = emptySet()

    override fun onServiceConnected() {
        super.onServiceConnected()
        Hub.accessibility = this
        ignored = buildIgnoredPackages()
    }

    private fun buildIgnoredPackages(): Set<String> {
        val set = mutableSetOf("com.android.systemui")
        // The keyboard pops up as its own window; don't treat it as "leaving the app".
        try {
            val imm = getSystemService(InputMethodManager::class.java)
            imm?.enabledInputMethodList?.forEach { set += it.packageName }
        } catch (_: Exception) {}
        try {
            Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ?.substringBefore('/')?.let { set += it }
        } catch (_: Exception) {}
        return set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignored) return
        Hub.foregroundPackage = pkg
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        showBadge(null)
        if (Hub.accessibility === this) Hub.accessibility = null
    }

    // ---------------- actions ----------------

    fun perform(action: Action) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        when (action) {
            Action.VOLUME_UP ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            Action.VOLUME_DOWN ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            Action.PLAY_PAUSE -> mediaKey(audio, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            Action.MEDIA_NEXT -> mediaKey(audio, KeyEvent.KEYCODE_MEDIA_NEXT)
            Action.MEDIA_PREVIOUS -> mediaKey(audio, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            Action.SWIPE_UP -> swipe(w / 2, h * 0.75f, w / 2, h * 0.25f)
            Action.SWIPE_DOWN -> swipe(w / 2, h * 0.25f, w / 2, h * 0.75f)
            Action.SWIPE_LEFT -> swipe(w * 0.85f, h / 2, w * 0.15f, h / 2)
            Action.SWIPE_RIGHT -> swipe(w * 0.15f, h / 2, w * 0.85f, h / 2)
            Action.TAP_CENTER -> tap(w / 2, h / 2, 1)
            Action.DOUBLE_TAP_RIGHT -> tap(w * 0.8f, h * 0.3f, 2)
            Action.DOUBLE_TAP_LEFT -> tap(w * 0.2f, h * 0.3f, 2)
            Action.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            Action.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            Action.NOTHING -> {}
        }
    }

    private fun mediaKey(audio: AudioManager, code: Int) {
        val t = SystemClock.uptimeMillis()
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        audio.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 250))
                .build(), null, null
        )
    }

    private fun tap(x: Float, y: Float, times: Int) {
        val builder = GestureDescription.Builder()
        for (i in 0 until times) {
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, i * 120L, 40))
        }
        dispatchGesture(builder.build(), null, null)
    }

    // ---------------- small floating badge ----------------

    /** Shows a little bubble with the gesture it sees; null hides it. Main thread only. */
    fun showBadge(text: String?) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (text == null) {
            badge?.let { runCatching { wm.removeView(it) } }
            badge = null
            return
        }
        val existing = badge
        if (existing != null) {
            if (existing.text != text) existing.text = text
            return
        }
        val dp = resources.displayMetrics.density
        val view = TextView(this).apply {
            this.text = text
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, 60, 30, 140))
            }
        }
        val size = (48 * dp).toInt()
        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = (12 * dp).toInt()
            y = (90 * dp).toInt()
        }
        runCatching { wm.addView(view, lp); badge = view }
    }
}
